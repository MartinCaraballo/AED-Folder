import java.util.Collection;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Ernesto
 */
public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
       /*  CARGAR EL GRAFO CON LA RED DE AEROPUERTOS Y VUELOS
         TGrafoDirigido gd = (TGrafoDirigido) UtilGrafos.cargarGrafo(....
        

        /* invocar a esPosibleLlegarATodos(Comparable aeropuertoOrigen) para cada 
         aeropuerto indicado en el documento / pizarrón, imprimir el resultado por pantalla
         y poner los resultados en la hoja de parcial distribuida.
         Poner también los resultados en el archivo de texto “vuelosAED.txt” 
         */
       
        /* invocar a esPosibleLlegarATodos2(Comparable aeropuertoOrigen) para cada 
         aeropuerto indicado en el documento / pizarrón, imprimir el resultado por pantalla
         y poner los resultados en la hoja de parcial distribuida.
         Poner también los resultados en el archivo de texto “vuelosAED.txt” 
        */
    }
}



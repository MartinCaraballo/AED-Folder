public class Parcial2 {

    public static void main(String[] args) {
        
        
        // CREAR EL GRAFO CON PERSONAS.TXT y CONTACTOS.TXT
        
        TGrafoContagios grafoTrazabilidad = (TGrafoContagios) UtilGrafos.cargarGrafo(
                "src/personas.txt",
                "src/contactos.txt",
                false, TGrafoContagios.class);

    
    
        
        String personaCOVID = "SE INDICARA EN EL PIZARRON";
        int maxDistancia = "NNN" SE INDICARA EN EL PIZARRON
        
        // invocar al método "anillosDeProbablesContagiados" con estos parámetros;

        // emitir por consola la cantidad de contactos que se encuentran a la distancia
        // de la personaCOVID indicada EN EL PIZARRÓN: distAnilloBuscar
         int distAnilloBuscar = SE INDICARA EN EL PIZARRÓN
                 
         // EMITIR EL ARCHIVO "ANILLOS.TXT", CON EL FORMATO INDICADO EN LA LETRA, 
         // CON LOS CONJUNTOS DE CONTACTOS HASTA UNA DISTANCIA MENOR O IGUAL A LA INDICADA
         // EN EL PIZARRÓN: distMaxParaArchivoListado
        
         int distMaxParaArchivoListado = // SE INDICARÁ EN EL PIZARRÓN
                  
        
        
        
       
    }
}

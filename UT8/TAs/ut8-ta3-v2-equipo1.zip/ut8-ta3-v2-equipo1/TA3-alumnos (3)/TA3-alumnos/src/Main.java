
import java.util.Collection;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Martin
 */
public class Main {

    public static void main(String[] args) {

        TGrafoNoDirigido grafoNoDirigido = UtilGrafos.cargarGrafo("src/verticesBEA.txt", "src/aristasBEA.txt", true, TGrafoNoDirigido.class);

        Collection<TVertice> resultado = grafoNoDirigido.bea("a");
        
        for (TVertice vertice : resultado) {
            System.out.println(vertice.getEtiqueta() + "-->");
        }
    }
}


import java.util.Collection;
import java.util.Map;

public interface IGrafoRedElectrica {

 
    public TAristas mejorRedElectrica();

    
}

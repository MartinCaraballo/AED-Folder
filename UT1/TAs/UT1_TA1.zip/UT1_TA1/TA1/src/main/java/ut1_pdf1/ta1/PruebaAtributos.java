package ut1_pdf1.ta1;

/**
 *
 * @author Administrador
 */
public class PruebaAtributos {
    //int goto = 4; //espera un identificador pero como goto es palabra reservada no lo reconoce
    //int 4;  // no es un nombre valido los ombres deben iniciar con minuscula
    int a;
    String Cadena; // lo toma como si fuera un metodo en teoria esta bien pero no deberia
    String hola = "hola";
    String chau;
  
    public void impress(float numero){
        String chain = "chain";
        int texto;
        // System.out.println(Cadena,goto,a); // 
        System.out.println(a);
        System.out.println(Cadena);
        System.out.println(hola);
        System.out.println(chau);
        System.out.println(chain);
        //System.out.println(texto);  //para imprimirla debemos inicializarla 
        System.out.println(numero);
    }
}

package ut1_pdf1.ta1;

/*
 * @author Equipo 8 
 */
public class Program {
    
    static float numero;
    
    public static void main(String[] args) {
        /*
        float numero2;
        PruebaAtributos cadena = new PruebaAtributos();
        cadena.impress(numero);
        //cadena.impress(numero2); // no se puede pasar una variable local no inincializada
        System.out.println("Hello World!");
        */
        int aNumber = 3;
        if (aNumber >= 0) {
            if (aNumber == 0) {
                System.out.println("first string");
            } else {
                System.out.println("second string");
            }
        }
        System.out.println("third string");
    }
}

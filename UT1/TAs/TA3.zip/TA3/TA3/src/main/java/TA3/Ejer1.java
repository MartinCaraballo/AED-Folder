package TA3;

import java.io.*;
import static java.lang.Character.isSpace;

public class Ejer1 {

    public static int ContadorPalabras(String texto) {
        int cont = 0;
        boolean isPalabra = false;
        texto = texto.trim();
        for (int i = 1; i < texto.length(); i++) {

            char character = texto.charAt(i);
            System.out.println(character);
            if (Character.isLetter(character)) {
                isPalabra = true;
                if (character == ' ' | isPalabra) {
                    cont++;
                    isPalabra = false;
                }
            }

        }
        return cont;
    }

    public static int ContadorMayores(String string, int x) {
        int cont = 0;
        int contadorPalabra = 0;
        boolean isPalabra = false;
        for (int i = 0; i < string.length(); i++) {
            char character = string.charAt(i);

            if (character != ' ') {
                contadorPalabra++;
                if (Character.isLetter(character)) {
                    isPalabra = true;
                }
            } else {
                if (isPalabra && contadorPalabra >= x) {
                    cont++;
                }
                contadorPalabra = 0;
                isPalabra = false;
            }
        }
        return cont;
    }

    public static int[] ContadorVocalesConsonantes(String frase) {
        int[] resultados = new int[2];
        String stringALeer = frase.toLowerCase();
        int contVocales = 0;
        int contConsonantes = 0;
        for (int i = 0; i < frase.length(); i++) {
            char characterLeido = frase.charAt(i);
            if (Character.isLetter(characterLeido)) {
                if (characterLeido == 'a' || characterLeido == 'e' || characterLeido == 'i' || characterLeido == 'o' || characterLeido == 'u') {
                    contVocales++;
                } else {
                    contConsonantes++;
                }
            }
        }
        resultados[0] = contVocales;
        resultados[1] = contConsonantes;
        return resultados;
    }

    public static void main(String[] args) {
        // Ejercicio 1
        System.out.println(ContadorPalabras("Hola como estas 4444 "));

        // Ejercicio 2 subEquipo B
        System.out.println(ContadorMayores("Hola como estas 654r4 6534", 4));

        // Ejercicio 2 subEquipo A
        int[] resultadoVocalesConsonantes = ContadorVocalesConsonantes(
                "Hola como estas 646kj54");
        System.out.println(
                "Cantidad de vocales: " + resultadoVocalesConsonantes[0]);
        System.out.println(
                "Cantidad de consonantes: " + resultadoVocalesConsonantes[1]);

        // Ejercicio 3
        LectorDeArchivos lectorDeArchivos = new LectorDeArchivos();
        String[] textoLeido = lectorDeArchivos.LeerArchivo(
                "C:\\Users\\Administrador\\OneDrive\\Escritorio\\TA3\\TA3\\src\\main\\java\\TA3\\entrada.txt");
        int contadorPalabras = 0;
        for (int i = 0; i < textoLeido.length; i++) {
            contadorPalabras += ContadorPalabras(textoLeido[i]);
        }
        System.out.println(contadorPalabras + "si");
    }
}

package TA3;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class LectorDeArchivos {

    public String[] LeerArchivo(String rutaArchivo) {
        try {
            File archivoEntrada = new File(rutaArchivo);
            BufferedReader lector = new BufferedReader(new FileReader(
                    archivoEntrada));
            String lineaActual = lector.readLine();
            int contLineas = 0;
            while (lineaActual != null) {
                System.out.println(lineaActual);
                lineaActual = lector.readLine();
                contLineas++;
            }
            String[] lineasLeidas = new String[contLineas];
            lector = new BufferedReader(new FileReader(
                    archivoEntrada));
            for(int i = 0; i < contLineas; i++){
                lineasLeidas[i] = lector.readLine();
            }
           
            return lineasLeidas;
            
        } catch (FileNotFoundException e) {
            System.out.println("Error al leer el archivo " + rutaArchivo);
        } catch (IOException e) {
            System.out.println("Error al leer el archivo " + rutaArchivo);
        }
        return null;
    }
}

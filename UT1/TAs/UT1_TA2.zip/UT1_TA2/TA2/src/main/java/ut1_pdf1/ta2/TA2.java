package ut1_pdf1.ta2;

/**
 * @author Equipo 8
 */
class TA2 {

    public static void main(String[] args) {
        int factorial = factorial(50);
        System.out.println(factorial);
    }

    public static int factorial(int num) {
        if (num > 0) {
            int resultado = 1;
            for (int i = 1; i <= num; i++) {
                resultado *= i;
            }
            return resultado;
        } else {
            //El factorial de 0 es 1
            System.out.println("No está definido.");
        }
        return 0;
    }
}

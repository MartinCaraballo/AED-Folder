package ut1_pdf1.ta2;

/**
 * @author Equipo 8
 */
public class Primo {

    public static boolean isPrime(long n) {
        boolean prime = true;
        for (long i = 3; i <= Math.sqrt(n); i += 2) {
            if (n % i == 0) {
                prime = false;
                break;
            }
        }
        if ((n % 2 != 0 && prime && n > 2) || n == 2) {
            return true;
        } else {
            return false;
        }
    }

    public static int suma(long n) {
        int i = 0;
        int suma = 0;
        if (isPrime(n)) {
            while (i <= n) {
                if (i % 2 == 0) {
                    suma += i;
                }
            }
        } else {
            while (i <= n) {
                if (i % 2 != 0) {
                    suma += i;
                }
            }
        }
        return suma;
    }

    public static void main(String[] args) {

        // no lo pudimos probar. Falta lo necesario para probar.
        System.out.println(suma(45769));
    }
}

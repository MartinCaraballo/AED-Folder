package com.mycompany.ut3_pd12;


/**
 *
 * @author ernesto
 * @param <T>
 */
public interface IConjunto {

    
    public Conjunto union (Conjunto otroConjunto);

    public Conjunto interseccion (Conjunto otroConjunto);
}

import java.util.LinkedList;

public class Main {

    /**
     * @param args
     */
    public static void main(String[] args) {
        TArbolBBU ucu  = new TArbolBBU();
       // cargar los alumnos en el árbol "ucu" desde el archivo de datos "datos.csv"
             
        
        
                
        //  String laCarrera =     // se indicará en el pizarrón
        
        TArbolBBU porCarrera = ucu.armarIndiceCarrera(laCarrera);
        
      
        
        // escribir en el archivo "salida.txt" el listado emitido de los alumnos
        // de la carrera indicada, en orden alfabético ascendente
        
        
    }

   

}

